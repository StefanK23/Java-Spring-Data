package PROJECT.entities;

public enum AgeRestriction {
    MINOR,TEEN,ADULT
}
