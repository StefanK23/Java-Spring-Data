package PROJECT.entities;

public enum EditionType {
    NORMAL,PROMO,GOLD
}
