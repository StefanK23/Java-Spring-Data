package PROJECT.services;

import PROJECT.entities.Author;

public interface AuthorService {

    Author getRandomAuthor();
}
