package com.example.workshop.Service;

import com.example.workshop.Repository.UserRepository;
import com.example.workshop.models.DTO.RegistrationDTO;
import com.example.workshop.models.User;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class UserService {

    private ModelMapper modelMapper;
    private UserRepository userRepository;

    @Autowired
    public UserService(ModelMapper modelMapper, UserRepository userRepository) {
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
    }

    public void register(RegistrationDTO dto){
        User user = this.modelMapper.map(dto, User.class);

        this.userRepository.save(user);
    }

}
