package softuni.exam.util.util;

public interface ValidationUtil {

    <E> boolean isValid(E entity);
}
